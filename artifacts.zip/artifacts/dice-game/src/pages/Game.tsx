import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, Volume2, VolumeX, Gift, ArrowLeft } from "lucide-react";
import { cn } from "@/lib/utils";
import { rollDice, sumDice } from "@/lib/gameLogic";
import { DieFace } from "@/components/DieFace";
import { Leaderboard } from "@/components/Leaderboard";
import { ResultOverlay } from "@/components/ResultOverlay";
import { DailyReward } from "@/components/DailyReward";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { saveScore } from "@/lib/leaderboard";
import { playRoll, playWin, playLose, playPush, setMuted } from "@/lib/sounds";
import { loadSave, saveProgress, isDailyRewardAvailable, claimDailyReward, DAILY_REWARD_AMOUNT } from "@/lib/persistence";

type GameState = "IDLE" | "ROLLING" | "RESULT" | "GAME_OVER";
type ResultType = "WIN" | "LOSE" | "PUSH" | null;

const saved = loadSave();

export default function Game() {
  const [, setLocation] = useLocation();
  const [coins, setCoins] = useState(saved.coins);
  const [bet, setBet] = useState(10);
  const [gameState, setGameState] = useState<GameState>("IDLE");

  const [playerDice, setPlayerDice] = useState<number[]>([1, 1]);
  const [dealerDice, setDealerDice] = useState<number[]>([1, 1]);

  const [result, setResult] = useState<ResultType>(null);
  const [coinDelta, setCoinDelta] = useState(0);
  const [showOverlay, setShowOverlay] = useState(false);

  const [rounds, setRounds] = useState(0);
  const [wins, setWins] = useState(0);
  const [losses, setLosses] = useState(0);
  const [pushes, setPushes] = useState(0);

  const [highScore, setHighScore] = useState(saved.highScore);
  const [isNewHighScore, setIsNewHighScore] = useState(false);

  const [showLeaderboard, setShowLeaderboard] = useState(false);
  const [muted, setMutedState] = useState(() => {
    setMuted(saved.muted);
    return saved.muted;
  });

  const [rewardAvailable, setRewardAvailable] = useState(() => isDailyRewardAvailable());
  const [showDailyReward, setShowDailyReward] = useState(() => isDailyRewardAvailable());

  const overlayTimer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const newHighScoreTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const betOptions = [5, 10, 25, 50];

  const toggleMute = () => {
    setMutedState(prev => {
      const next = !prev;
      setMuted(next);
      saveProgress({ muted: next });
      return next;
    });
  };

  const handleClaimReward = () => {
    claimDailyReward();
    setRewardAvailable(false);
    const next = coins + DAILY_REWARD_AMOUNT;
    setCoins(next);
    setHighScore(prev => {
      const hs = Math.max(prev, next);
      saveProgress({ coins: next, highScore: hs });
      return hs;
    });
  };

  useEffect(() => {
    if (bet > coins && coins > 0) {
      const highestAffordable = [...betOptions].reverse().find(b => b <= coins);
      if (highestAffordable) setBet(highestAffordable);
    }
  }, [coins, bet]);

  const handleRoll = () => {
    if (coins < bet) return;

    playRoll();
    setGameState("ROLLING");
    setResult(null);
    setShowOverlay(false);
    setIsNewHighScore(false);
    if (overlayTimer.current) clearTimeout(overlayTimer.current);
    if (newHighScoreTimer.current) clearTimeout(newHighScoreTimer.current);

    setTimeout(() => {
      const pDice = rollDice(2);
      const dDice = rollDice(2);

      setPlayerDice(pDice);
      setDealerDice(dDice);

      const pSum = sumDice(pDice);
      const dSum = sumDice(dDice);

      let currentResult: ResultType = "PUSH";
      let delta = 0;
      let nextCoins = coins;

      if (pSum > dSum) {
        currentResult = "WIN";
        delta = bet;
        nextCoins = coins + bet;
        setCoins(nextCoins);
        setWins(w => w + 1);
        playWin();
      } else if (pSum < dSum) {
        currentResult = "LOSE";
        delta = bet;
        nextCoins = coins - bet;
        setCoins(nextCoins);
        setLosses(l => l + 1);
        playLose();
      } else {
        playPush();
        setPushes(p => p + 1);
      }

      setHighScore(prev => {
        const next = Math.max(prev, nextCoins);
        if (next > prev) {
          setIsNewHighScore(true);
          newHighScoreTimer.current = setTimeout(() => setIsNewHighScore(false), 3000);
          saveProgress({ coins: nextCoins, highScore: next });
        } else {
          saveProgress({ coins: nextCoins });
        }
        return next;
      });

      setCoinDelta(delta);
      setResult(currentResult);
      setRounds(r => r + 1);
      setGameState("RESULT");
      setShowOverlay(true);

      overlayTimer.current = setTimeout(() => setShowOverlay(false), 1600);
    }, 1000);
  };

  useEffect(() => {
    if (gameState === "RESULT" && coins <= 0) {
      saveScore({ coins: 0, rounds, wins, losses, pushes });
      saveProgress({ coins: 100 });
      setTimeout(() => setGameState("GAME_OVER"), 2000);
    }
  }, [gameState, coins]);

  useEffect(() => () => {
    if (overlayTimer.current) clearTimeout(overlayTimer.current);
    if (newHighScoreTimer.current) clearTimeout(newHighScoreTimer.current);
  }, []);

  const resetGame = () => {
    setCoins(100);
    setBet(10);
    setGameState("IDLE");
    setResult(null);
    setShowOverlay(false);
    setIsNewHighScore(false);
    setRounds(0);
    setWins(0);
    setLosses(0);
    setPushes(0);
    setPlayerDice([1, 1]);
    setDealerDice([1, 1]);
    saveProgress({ coins: 100 });
  };

  const handleCashOut = () => {
    if (rounds > 0) saveScore({ coins, rounds, wins, losses, pushes });
    resetGame();
  };

  const getResultGlow = () => {
    if (result === "WIN") return "glow-primary border-primary";
    if (result === "LOSE") return "glow-destructive border-destructive";
    if (result === "PUSH") return "glow-muted border-muted";
    return "border-transparent";
  };

  return (
    <motion.div
      className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center p-4 sm:p-8 font-sans overflow-hidden relative"
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.22, ease: [0.25, 0.46, 0.45, 0.94] }}
    >

      <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-primary/10 rounded-full blur-[100px] pointer-events-none" />
      <div className="absolute bottom-[-10%] right-[-10%] w-[40%] h-[40%] bg-destructive/10 rounded-full blur-[100px] pointer-events-none" />

      <ResultOverlay result={result} visible={showOverlay} coinDelta={coinDelta} />

      <div className="w-full max-w-3xl z-10 flex flex-col gap-6">

        {/* Header */}
        <header className="flex justify-between items-center bg-card/80 backdrop-blur-md p-4 sm:p-6 rounded-2xl border border-border shadow-lg">
          <div className="flex items-center gap-4">
            <button
              onClick={() => setLocation("/")}
              disabled={gameState === "ROLLING"}
              className="text-muted-foreground hover:text-foreground transition-colors disabled:opacity-30 shrink-0"
              data-testid="button-home"
              title="Home"
            >
              <ArrowLeft className="w-5 h-5" />
            </button>
          <div className="flex flex-col gap-0.5">
            <span className="text-sm text-muted-foreground font-mono uppercase tracking-wider">Balance</span>
            <div className="flex items-baseline gap-2">
              <motion.span
                key={coins}
                initial={{ scale: 1.25, color: result === "WIN" ? "#fbbf24" : result === "LOSE" ? "#f87171" : "#fbbf24" }}
                animate={{ scale: 1, color: "#fbbf24" }}
                transition={{ type: "spring", stiffness: 400, damping: 18 }}
                className="text-3xl sm:text-4xl font-bold text-primary drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]"
                data-testid="text-coins"
              >
                {coins}
              </motion.span>
              <span className="text-lg text-primary/70">CR</span>
            </div>
            <div className="flex items-center gap-1.5 mt-0.5" data-testid="high-score-row">
              <Trophy className="w-3 h-3 text-muted-foreground/60" />
              <span className="text-xs font-mono text-muted-foreground/60 uppercase tracking-wider">Best</span>
              <motion.span
                key={highScore}
                initial={isNewHighScore ? { scale: 1.4, color: "#fbbf24" } : false}
                animate={{ scale: 1, color: isNewHighScore ? "#fbbf24" : "hsl(215 20% 65%)" }}
                transition={{ type: "spring", stiffness: 300, damping: 16 }}
                className={cn(
                  "text-xs font-mono font-bold tracking-wider",
                  isNewHighScore ? "text-primary" : "text-muted-foreground/60"
                )}
                data-testid="text-high-score"
              >
                {highScore}
              </motion.span>
              <AnimatePresence>
                {isNewHighScore && (
                  <motion.span
                    initial={{ opacity: 0, x: -4 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0 }}
                    className="text-xs font-mono font-bold text-primary uppercase tracking-widest"
                    data-testid="new-high-score-badge"
                  >
                    New!
                  </motion.span>
                )}
              </AnimatePresence>
            </div>
          </div>
          </div>

          <div className="flex gap-3 items-center">
            <div className="hidden sm:flex flex-col text-right">
              <span className="text-xs text-muted-foreground font-mono uppercase">Record</span>
              <span className="font-mono text-sm font-bold text-foreground">
                <span className="text-primary">{wins}W</span>
                {" - "}
                <span className="text-destructive">{losses}L</span>
                {" - "}
                <span className="text-muted-foreground">{pushes}P</span>
              </span>
            </div>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowDailyReward(true)}
              className={cn(
                "relative transition-colors",
                rewardAvailable
                  ? "border-primary/50 text-primary shadow-[0_0_10px_rgba(234,179,8,0.2)]"
                  : "text-muted-foreground"
              )}
              data-testid="button-daily-reward"
              title="Daily Reward"
            >
              <Gift className="w-4 h-4" />
              {rewardAvailable && (
                <span className="absolute -top-1 -right-1 w-2.5 h-2.5 rounded-full bg-primary animate-pulse" />
              )}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={toggleMute}
              className={cn("transition-colors", muted && "text-muted-foreground border-muted-foreground/30")}
              data-testid="button-mute-toggle"
              title={muted ? "Unmute" : "Mute"}
            >
              {muted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => setShowLeaderboard(true)}
              className="gap-1.5"
              data-testid="button-open-leaderboard"
            >
              <Trophy className="w-4 h-4 text-primary" />
              <span className="hidden sm:inline">Scores</span>
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={handleCashOut}
              disabled={gameState === "ROLLING"}
              data-testid="button-cash-out"
            >
              Cash Out
            </Button>
          </div>
        </header>

        {gameState === "GAME_OVER" ? (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="flex flex-col items-center justify-center py-12 gap-6 bg-card border border-border rounded-2xl shadow-xl"
            data-testid="game-over-screen"
          >
            <h2 className="text-4xl sm:text-6xl font-bold text-destructive drop-shadow-[0_0_15px_rgba(239,68,68,0.8)] tracking-tighter uppercase">
              Busted
            </h2>
            <p className="text-muted-foreground font-mono">
              You survived {rounds} round{rounds !== 1 ? "s" : ""}.
            </p>
            <div className="flex items-center gap-2 text-sm font-mono text-muted-foreground/70">
              <Trophy className="w-3.5 h-3.5 text-primary/60" />
              <span>All-time best: <span className="text-primary font-bold">{highScore} CR</span></span>
            </div>
            <div className="flex gap-3">
              <Button
                size="lg"
                variant="outline"
                onClick={() => setShowLeaderboard(true)}
                className="gap-2"
                data-testid="button-view-scores"
              >
                <Trophy className="w-4 h-4 text-primary" />
                View Scores
              </Button>
              <Button
                size="lg"
                className="text-lg px-8 py-6 uppercase tracking-widest font-bold bg-primary text-primary-foreground hover:bg-primary/90"
                onClick={resetGame}
                data-testid="button-play-again"
              >
                Play Again
              </Button>
            </div>
          </motion.div>
        ) : (
          <>
            {/* Play Area */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">

              {/* Dealer Side */}
              <Card className="bg-card/50 backdrop-blur border-border/50 relative overflow-hidden group">
                <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                <CardHeader className="pb-2">
                  <CardTitle className="text-center font-mono text-muted-foreground uppercase tracking-widest text-sm">The House</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center gap-6 py-6">
                  <div className="flex gap-4">
                    <DieFace value={dealerDice[0]} isRolling={gameState === "ROLLING"} className="bg-secondary text-secondary-foreground border-border/50 shadow-none" />
                    <DieFace value={dealerDice[1]} isRolling={gameState === "ROLLING"} className="bg-secondary text-secondary-foreground border-border/50 shadow-none" />
                  </div>
                  <div className="h-8 flex items-center justify-center">
                    <AnimatePresence mode="popLayout">
                      {gameState === "RESULT" && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.8 }}
                          animate={{ opacity: 1, scale: 1 }}
                          exit={{ opacity: 0 }}
                          className="font-mono text-2xl font-bold text-muted-foreground"
                          data-testid="text-dealer-sum"
                        >
                          {sumDice(dealerDice)}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </CardContent>
              </Card>

              {/* Player Side */}
              <Card className={cn("bg-card/80 backdrop-blur border-2 transition-all duration-500 relative overflow-hidden", getResultGlow())}>
                <div className="absolute inset-0 bg-gradient-to-t from-primary/5 to-transparent pointer-events-none" />
                <CardHeader className="pb-2">
                  <CardTitle className="text-center font-mono text-primary uppercase tracking-widest text-sm drop-shadow-sm">Player</CardTitle>
                </CardHeader>
                <CardContent className="flex flex-col items-center gap-6 py-6">
                  <div className="flex gap-4">
                    <DieFace value={playerDice[0]} isRolling={gameState === "ROLLING"} />
                    <DieFace value={playerDice[1]} isRolling={gameState === "ROLLING"} />
                  </div>
                  <div className="h-8 flex items-center justify-center">
                    <AnimatePresence mode="popLayout">
                      {gameState === "RESULT" && (
                        <motion.div
                          initial={{ opacity: 0, scale: 0.5, y: 10 }}
                          animate={{ opacity: 1, scale: 1, y: 0 }}
                          exit={{ opacity: 0 }}
                          className={cn(
                            "font-mono text-3xl font-black drop-shadow-md",
                            result === "WIN" ? "text-primary" : result === "LOSE" ? "text-destructive" : "text-muted-foreground"
                          )}
                          data-testid="text-player-sum"
                        >
                          {sumDice(playerDice)}
                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Controls */}
            <Card className="bg-card/90 backdrop-blur-md border-border">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-6 items-center justify-between">
                  <div className="flex flex-col gap-3 w-full sm:w-auto">
                    <span className="text-xs text-muted-foreground font-mono uppercase tracking-widest text-center sm:text-left">Wager</span>
                    <div className="flex gap-2 justify-center sm:justify-start">
                      {betOptions.map(amount => {
                        const canAfford = amount <= coins;
                        return (
                          <Button
                            key={amount}
                            variant={bet === amount ? "default" : "outline"}
                            size="sm"
                            className={cn(
                              "font-mono font-bold transition-all",
                              bet === amount ? "shadow-[0_0_15px_rgba(234,179,8,0.4)] border-primary" : "",
                              !canAfford && "opacity-30 grayscale cursor-not-allowed"
                            )}
                            onClick={() => setBet(amount)}
                            disabled={!canAfford || gameState === "ROLLING"}
                            data-testid={`button-bet-${amount}`}
                          >
                            {amount}
                          </Button>
                        );
                      })}
                    </div>
                  </div>

                  <Button
                    size="lg"
                    className="w-full sm:w-48 h-16 text-xl uppercase font-black tracking-widest shadow-[0_0_20px_rgba(234,179,8,0.3)] hover:shadow-[0_0_30px_rgba(234,179,8,0.6)] transition-all"
                    onClick={handleRoll}
                    disabled={gameState === "ROLLING" || coins < bet}
                    data-testid="button-roll"
                  >
                    {gameState === "ROLLING" ? "Rolling..." : "Roll Dice"}
                  </Button>
                </div>
              </CardContent>
            </Card>
          </>
        )}
      </div>

      <Leaderboard
        visible={showLeaderboard}
        onClose={() => setShowLeaderboard(false)}
      />

      <DailyReward
        visible={showDailyReward}
        available={rewardAvailable}
        onClaim={handleClaimReward}
        onClose={() => setShowDailyReward(false)}
      />
    </motion.div>
  );
}
