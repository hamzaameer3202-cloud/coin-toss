import { useState } from "react";
import { useLocation } from "wouter";
import { motion } from "framer-motion";
import { Trophy, Gift, ChevronRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DailyReward } from "@/components/DailyReward";
import { loadSave, isDailyRewardAvailable, claimDailyReward, DAILY_REWARD_AMOUNT } from "@/lib/persistence";

const saved = loadSave();

const stagger = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09 } },
};

const fadeUp = {
  hidden: { opacity: 0, y: 28 },
  show: { opacity: 1, y: 0, transition: { type: "spring", stiffness: 260, damping: 22 } },
};

const fadeIn = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { duration: 0.5 } },
};

function DieLogo({ value, delay }: { value: number; delay: number }) {
  const dots: Record<number, string[]> = {
    1: ["g"],
    2: ["a", "b"],
    3: ["a", "g", "b"],
    4: ["a", "c", "d", "b"],
    5: ["a", "c", "g", "d", "b"],
    6: ["a", "c", "e", "f", "d", "b"],
  };
  const areas = dots[value] ?? [];

  return (
    <motion.div
      className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl bg-primary border-2 border-amber-300/40 shadow-[0_0_32px_rgba(234,179,8,0.45)] grid"
      style={{
        gridTemplateAreas: `"a . c" "e g f" "d . b"`,
        gridTemplateColumns: "1fr 1fr 1fr",
        gridTemplateRows: "1fr 1fr 1fr",
        padding: "14%",
      }}
      animate={{ y: [0, -8, 0], rotate: [0, 3, -3, 0] }}
      transition={{ duration: 3.6, delay, repeat: Infinity, ease: "easeInOut" }}
    >
      {areas.map((area) => (
        <div
          key={area}
          className="rounded-full bg-primary-foreground/90 w-[55%] h-[55%] justify-self-center self-center"
          style={{ gridArea: area }}
        />
      ))}
    </motion.div>
  );
}

export default function Home() {
  const [, setLocation] = useLocation();
  const [coins, setCoins] = useState(saved.coins);
  const [highScore, setHighScore] = useState(saved.highScore);
  const [rewardAvailable, setRewardAvailable] = useState(() => isDailyRewardAvailable());
  const [showReward, setShowReward] = useState(false);

  const handleClaimReward = () => {
    claimDailyReward();
    setRewardAvailable(false);
    const next = coins + DAILY_REWARD_AMOUNT;
    setCoins(next);
    if (next > highScore) setHighScore(next);
  };

  const handlePlay = () => setLocation("/game");

  return (
    <motion.div
      className="min-h-screen bg-background text-foreground flex flex-col items-center justify-center relative overflow-hidden px-6 py-10"
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -8 }}
      transition={{ duration: 0.22, ease: [0.25, 0.46, 0.45, 0.94] }}
    >

      {/* Ambient background orbs */}
      <motion.div
        className="absolute w-[520px] h-[520px] rounded-full bg-primary/8 blur-[120px] pointer-events-none"
        animate={{ x: [0, 40, -20, 0], y: [0, -30, 20, 0] }}
        transition={{ duration: 18, repeat: Infinity, ease: "easeInOut" }}
        style={{ top: "-15%", left: "-15%" }}
      />
      <motion.div
        className="absolute w-[400px] h-[400px] rounded-full bg-destructive/6 blur-[100px] pointer-events-none"
        animate={{ x: [0, -30, 15, 0], y: [0, 25, -15, 0] }}
        transition={{ duration: 22, repeat: Infinity, ease: "easeInOut", delay: 3 }}
        style={{ bottom: "-10%", right: "-10%" }}
      />
      <motion.div
        className="absolute w-[300px] h-[300px] rounded-full bg-primary/5 blur-[80px] pointer-events-none"
        animate={{ x: [0, 20, -10, 0], y: [0, -20, 30, 0] }}
        transition={{ duration: 15, repeat: Infinity, ease: "easeInOut", delay: 6 }}
        style={{ top: "40%", right: "5%" }}
      />

      {/* Main content */}
      <motion.div
        className="relative z-10 flex flex-col items-center gap-10 w-full max-w-sm"
        variants={stagger}
        initial="hidden"
        animate="show"
      >

        {/* Logo */}
        <motion.div variants={fadeUp} className="flex flex-col items-center gap-6">
          <div className="flex items-center gap-5">
            <DieLogo value={6} delay={0} />
            <DieLogo value={5} delay={0.4} />
          </div>

          <div className="flex flex-col items-center gap-2">
            <motion.h1
              className="text-5xl sm:text-6xl font-black uppercase tracking-tight leading-none text-center"
              style={{ fontFamily: "var(--app-font-sans)" }}
            >
              <span className="text-primary drop-shadow-[0_0_28px_rgba(234,179,8,0.7)]">High</span>
              <span className="text-foreground"> Roll</span>
            </motion.h1>
            <motion.p
              variants={fadeIn}
              className="text-muted-foreground font-mono text-xs uppercase tracking-[0.2em]"
            >
              Beat the house. Keep the gold.
            </motion.p>
          </div>
        </motion.div>

        {/* Balance card */}
        <motion.div
          variants={fadeUp}
          className="w-full bg-card/70 backdrop-blur-md border border-border rounded-2xl px-6 py-4 flex items-center justify-between"
          data-testid="home-balance-card"
        >
          <div className="flex flex-col gap-0.5">
            <span className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Balance</span>
            <div className="flex items-baseline gap-1.5">
              <span
                className="text-3xl font-black text-primary drop-shadow-[0_0_10px_rgba(234,179,8,0.5)]"
                data-testid="home-text-coins"
              >
                {coins}
              </span>
              <span className="text-base text-primary/60 font-mono">CR</span>
            </div>
          </div>
          <div className="flex flex-col items-end gap-0.5">
            <span className="text-xs font-mono text-muted-foreground uppercase tracking-widest">Best</span>
            <div className="flex items-center gap-1.5">
              <Trophy className="w-3.5 h-3.5 text-primary/60" />
              <span
                className="text-lg font-bold font-mono text-muted-foreground"
                data-testid="home-text-high-score"
              >
                {highScore}
              </span>
            </div>
          </div>
        </motion.div>

        {/* Daily reward shortcut */}
        {rewardAvailable && (
          <motion.button
            variants={fadeUp}
            onClick={() => setShowReward(true)}
            className="w-full flex items-center justify-between px-5 py-3.5 rounded-2xl bg-primary/10 border border-primary/30 hover:bg-primary/15 hover:border-primary/50 transition-all group"
            data-testid="home-daily-reward-button"
          >
            <div className="flex items-center gap-3">
              <div className="relative">
                <Gift className="w-5 h-5 text-primary" />
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-primary animate-pulse" />
              </div>
              <div className="text-left">
                <p className="text-sm font-bold text-primary font-mono uppercase tracking-wider">Daily Reward</p>
                <p className="text-xs text-muted-foreground font-mono">+{DAILY_REWARD_AMOUNT} coins waiting</p>
              </div>
            </div>
            <ChevronRight className="w-4 h-4 text-primary/60 group-hover:text-primary transition-colors" />
          </motion.button>
        )}

        {/* Play button */}
        <motion.div variants={fadeUp} className="w-full">
          <motion.button
            onClick={handlePlay}
            className="w-full h-18 rounded-2xl bg-primary text-primary-foreground font-black text-2xl uppercase tracking-[0.15em] shadow-[0_0_30px_rgba(234,179,8,0.4)] hover:shadow-[0_0_50px_rgba(234,179,8,0.7)] transition-all active:scale-[0.97]"
            style={{ height: "72px", fontFamily: "var(--app-font-sans)" }}
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.97 }}
            data-testid="button-play"
          >
            Play
          </motion.button>
        </motion.div>

        {/* Footer link */}
        <motion.div variants={fadeUp}>
          <button
            onClick={() => setLocation("/game")}
            className="text-xs font-mono text-muted-foreground/50 hover:text-muted-foreground uppercase tracking-widest transition-colors flex items-center gap-1.5"
            data-testid="home-link-leaderboard"
          >
            <Trophy className="w-3 h-3" />
            Leaderboard
          </button>
        </motion.div>

      </motion.div>

      <DailyReward
        visible={showReward}
        available={rewardAvailable}
        onClaim={handleClaimReward}
        onClose={() => setShowReward(false)}
      />
    </motion.div>
  );
}
