let ctx: AudioContext | null = null;
let muted = false;

function getCtx(): AudioContext {
  if (!ctx) ctx = new AudioContext();
  return ctx;
}

export function setMuted(value: boolean) {
  muted = value;
}

export function getMuted(): boolean {
  return muted;
}

function ramp(param: AudioParam, from: number, to: number, duration: number, ac: AudioContext) {
  param.setValueAtTime(from, ac.currentTime);
  param.linearRampToValueAtTime(to, ac.currentTime + duration);
}

export function playRoll() {
  if (muted) return;
  const ac = getCtx();
  const count = 8;
  for (let i = 0; i < count; i++) {
    const delay = i * 0.09;
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.connect(gain);
    gain.connect(ac.destination);
    osc.type = "square";
    osc.frequency.value = 120 + Math.random() * 60;
    gain.gain.setValueAtTime(0, ac.currentTime + delay);
    gain.gain.linearRampToValueAtTime(0.08, ac.currentTime + delay + 0.01);
    gain.gain.linearRampToValueAtTime(0, ac.currentTime + delay + 0.05);
    osc.start(ac.currentTime + delay);
    osc.stop(ac.currentTime + delay + 0.06);
  }
}

export function playWin() {
  if (muted) return;
  const ac = getCtx();
  const notes = [523.25, 659.25, 783.99, 1046.5];
  notes.forEach((freq, i) => {
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.connect(gain);
    gain.connect(ac.destination);
    osc.type = "sine";
    osc.frequency.value = freq;
    const t = ac.currentTime + i * 0.12;
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.18, t + 0.04);
    gain.gain.linearRampToValueAtTime(0, t + 0.22);
    osc.start(t);
    osc.stop(t + 0.25);
  });

  setTimeout(() => {
    if (muted) return;
    const ac2 = getCtx();
    const osc = ac2.createOscillator();
    const gain = ac2.createGain();
    osc.connect(gain);
    gain.connect(ac2.destination);
    osc.type = "sine";
    osc.frequency.value = 1046.5;
    ramp(osc.frequency, 1046.5, 1400, 0.2, ac2);
    gain.gain.setValueAtTime(0.15, ac2.currentTime);
    gain.gain.linearRampToValueAtTime(0, ac2.currentTime + 0.3);
    osc.start(ac2.currentTime);
    osc.stop(ac2.currentTime + 0.3);
  }, 480);
}

export function playLose() {
  if (muted) return;
  const ac = getCtx();
  const notes = [350, 290, 240, 180];
  notes.forEach((freq, i) => {
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.connect(gain);
    gain.connect(ac.destination);
    osc.type = "sawtooth";
    osc.frequency.value = freq;
    const t = ac.currentTime + i * 0.13;
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.12, t + 0.05);
    gain.gain.linearRampToValueAtTime(0, t + 0.18);
    osc.start(t);
    osc.stop(t + 0.2);
  });
}

export function playPush() {
  if (muted) return;
  const ac = getCtx();
  [440, 440].forEach((freq, i) => {
    const osc = ac.createOscillator();
    const gain = ac.createGain();
    osc.connect(gain);
    gain.connect(ac.destination);
    osc.type = "sine";
    osc.frequency.value = freq;
    const t = ac.currentTime + i * 0.18;
    gain.gain.setValueAtTime(0, t);
    gain.gain.linearRampToValueAtTime(0.1, t + 0.04);
    gain.gain.linearRampToValueAtTime(0, t + 0.15);
    osc.start(t);
    osc.stop(t + 0.16);
  });
}
