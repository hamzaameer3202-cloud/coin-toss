export function rollDie(): number {
  return Math.floor(Math.random() * 6) + 1;
}

export function rollDice(count: number = 2): number[] {
  return Array.from({ length: count }, rollDie);
}

export function sumDice(dice: number[]): number {
  return dice.reduce((acc, curr) => acc + curr, 0);
}
