export interface LeaderboardEntry {
  id: string;
  coins: number;
  rounds: number;
  wins: number;
  losses: number;
  pushes: number;
  date: string;
}

const STORAGE_KEY = "dice-game-leaderboard";
const MAX_ENTRIES = 10;

export function getLeaderboard(): LeaderboardEntry[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return [];
    return JSON.parse(raw) as LeaderboardEntry[];
  } catch {
    return [];
  }
}

export function saveScore(entry: Omit<LeaderboardEntry, "id" | "date">): void {
  const existing = getLeaderboard();
  const newEntry: LeaderboardEntry = {
    ...entry,
    id: crypto.randomUUID(),
    date: new Date().toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }),
  };
  const updated = [newEntry, ...existing]
    .sort((a, b) => b.coins - a.coins)
    .slice(0, MAX_ENTRIES);
  localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
}

export function clearLeaderboard(): void {
  localStorage.removeItem(STORAGE_KEY);
}
