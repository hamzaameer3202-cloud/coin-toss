const KEY = "dice-game-save";

export interface SaveData {
  coins: number;
  highScore: number;
  muted: boolean;
  lastClaimDate: string | null;
}

const DEFAULTS: SaveData = {
  coins: 100,
  highScore: 100,
  muted: false,
  lastClaimDate: null,
};

export function loadSave(): SaveData {
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return { ...DEFAULTS };
    const parsed = JSON.parse(raw) as Partial<SaveData>;
    return {
      coins: typeof parsed.coins === "number" && parsed.coins > 0 ? parsed.coins : DEFAULTS.coins,
      highScore: typeof parsed.highScore === "number" ? parsed.highScore : DEFAULTS.highScore,
      muted: typeof parsed.muted === "boolean" ? parsed.muted : DEFAULTS.muted,
      lastClaimDate: typeof parsed.lastClaimDate === "string" ? parsed.lastClaimDate : null,
    };
  } catch {
    return { ...DEFAULTS };
  }
}

export function saveProgress(data: Partial<SaveData>): void {
  try {
    const current = loadSave();
    localStorage.setItem(KEY, JSON.stringify({ ...current, ...data }));
  } catch {
    // storage unavailable — silent no-op
  }
}

export function clearSave(): void {
  localStorage.removeItem(KEY);
}

export const DAILY_REWARD_AMOUNT = 50;

export function todayKey(): string {
  return new Date().toISOString().slice(0, 10);
}

export function isDailyRewardAvailable(): boolean {
  const { lastClaimDate } = loadSave();
  return lastClaimDate !== todayKey();
}

export function claimDailyReward(): void {
  saveProgress({ lastClaimDate: todayKey() });
}

export function msUntilNextReward(): number {
  const now = new Date();
  const tomorrow = new Date(now);
  tomorrow.setDate(tomorrow.getDate() + 1);
  tomorrow.setHours(0, 0, 0, 0);
  return tomorrow.getTime() - now.getTime();
}
