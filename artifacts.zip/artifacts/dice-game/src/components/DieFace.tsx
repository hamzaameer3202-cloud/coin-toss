import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { cn } from "@/lib/utils";

interface DieFaceProps {
  value: number;
  isRolling?: boolean;
  className?: string;
}

function DotLayout({ value }: { value: number }) {
  switch (value) {
    case 1:
      return <div className="dot dot-1" />;
    case 2:
      return (
        <>
          <div className="dot dot-2-1" />
          <div className="dot dot-2-2" />
        </>
      );
    case 3:
      return (
        <>
          <div className="dot dot-3-1" />
          <div className="dot dot-3-2" />
          <div className="dot dot-3-3" />
        </>
      );
    case 4:
      return (
        <>
          <div className="dot dot-4-1" />
          <div className="dot dot-4-2" />
          <div className="dot dot-4-3" />
          <div className="dot dot-4-4" />
        </>
      );
    case 5:
      return (
        <>
          <div className="dot dot-5-1" />
          <div className="dot dot-5-2" />
          <div className="dot dot-5-3" />
          <div className="dot dot-5-4" />
          <div className="dot dot-5-5" />
        </>
      );
    case 6:
      return (
        <>
          <div className="dot dot-6-1" />
          <div className="dot dot-6-2" />
          <div className="dot dot-6-3" />
          <div className="dot dot-6-4" />
          <div className="dot dot-6-5" />
          <div className="dot dot-6-6" />
        </>
      );
    default:
      return null;
  }
}

export function DieFace({ value, isRolling = false, className }: DieFaceProps) {
  const safeValue = Math.max(1, Math.min(6, value));
  const [displayValue, setDisplayValue] = useState(safeValue);

  useEffect(() => {
    if (!isRolling) {
      setDisplayValue(safeValue);
      return;
    }
    let speed = 60;
    let elapsed = 0;
    let timer: ReturnType<typeof setTimeout>;

    const tick = () => {
      setDisplayValue(Math.ceil(Math.random() * 6));
      elapsed += speed;
      if (elapsed < 600) speed = 60;
      else if (elapsed < 800) speed = 100;
      else speed = 140;
      timer = setTimeout(tick, speed);
    };

    timer = setTimeout(tick, speed);
    return () => clearTimeout(timer);
  }, [isRolling, safeValue]);

  return (
    <motion.div
      className={cn(
        "die-grid w-16 h-16 sm:w-20 sm:h-20 bg-primary text-primary-foreground rounded-2xl shadow-xl shadow-black/50 border border-amber-300/30",
        className
      )}
      animate={
        isRolling
          ? {
              rotate: [0, -15, 18, -10, 14, -8, 0],
              y: [0, -6, 4, -8, 3, -4, 0],
              scale: [1, 1.07, 0.96, 1.04, 0.98, 1.03, 1],
            }
          : { rotate: 0, y: 0, scale: 1 }
      }
      transition={
        isRolling
          ? { duration: 0.55, ease: "easeInOut", repeat: Infinity, repeatType: "loop" }
          : { type: "spring", stiffness: 400, damping: 18 }
      }
    >
      <DotLayout value={displayValue} />
    </motion.div>
  );
}
