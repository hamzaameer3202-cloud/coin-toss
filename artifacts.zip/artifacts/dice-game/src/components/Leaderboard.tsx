import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Trophy, X, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { getLeaderboard, clearLeaderboard, type LeaderboardEntry } from "@/lib/leaderboard";

interface LeaderboardProps {
  onClose: () => void;
  visible: boolean;
}

export function Leaderboard({ onClose, visible }: LeaderboardProps) {
  const [entries, setEntries] = useState<LeaderboardEntry[]>(() => getLeaderboard());

  const handleClear = () => {
    clearLeaderboard();
    setEntries([]);
  };

  return (
    <AnimatePresence>
      {visible && (
        <>
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/70 backdrop-blur-sm z-40"
            onClick={onClose}
          />
          <motion.div
            key="panel"
            initial={{ opacity: 0, y: 40, scale: 0.97 }}
            animate={{ opacity: 1, y: 0, scale: 1 }}
            exit={{ opacity: 0, y: 40, scale: 0.97 }}
            transition={{ type: "spring", damping: 22, stiffness: 280 }}
            className="fixed inset-x-4 top-1/2 -translate-y-1/2 max-w-md mx-auto z-50 bg-card border border-border rounded-2xl shadow-2xl overflow-hidden"
            data-testid="leaderboard-panel"
          >
            <div className="flex items-center justify-between px-6 py-4 border-b border-border">
              <div className="flex items-center gap-2">
                <Trophy className="w-5 h-5 text-primary" />
                <h2 className="font-bold text-lg font-mono uppercase tracking-widest text-foreground">
                  Leaderboard
                </h2>
              </div>
              <div className="flex items-center gap-2">
                {entries.length > 0 && (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={handleClear}
                    className="text-muted-foreground hover:text-destructive"
                    data-testid="button-clear-leaderboard"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={onClose}
                  data-testid="button-close-leaderboard"
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div className="overflow-y-auto max-h-[60vh]">
              {entries.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-16 gap-3 text-muted-foreground">
                  <Trophy className="w-10 h-10 opacity-20" />
                  <p className="font-mono text-sm uppercase tracking-wider">No scores yet</p>
                  <p className="text-xs opacity-60">Cash out or bust to record a score</p>
                </div>
              ) : (
                <div className="divide-y divide-border">
                  {entries.map((entry, index) => (
                    <div
                      key={entry.id}
                      className={cn(
                        "flex items-center gap-4 px-6 py-4 transition-colors",
                        index === 0 && "bg-primary/5"
                      )}
                      data-testid={`leaderboard-entry-${index}`}
                    >
                      <div className={cn(
                        "w-8 h-8 rounded-full flex items-center justify-center font-black font-mono text-sm shrink-0",
                        index === 0 ? "bg-primary text-primary-foreground shadow-[0_0_12px_rgba(234,179,8,0.5)]" :
                        index === 1 ? "bg-muted text-muted-foreground" :
                        index === 2 ? "bg-secondary text-secondary-foreground" :
                        "bg-transparent text-muted-foreground border border-border"
                      )}>
                        {index + 1}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-baseline gap-1.5">
                          <span className={cn(
                            "text-2xl font-black font-mono",
                            index === 0 ? "text-primary drop-shadow-[0_0_8px_rgba(234,179,8,0.6)]" : "text-foreground"
                          )}>
                            {entry.coins}
                          </span>
                          <span className="text-xs text-muted-foreground font-mono">CR</span>
                        </div>
                        <div className="flex gap-2 text-xs font-mono text-muted-foreground mt-0.5">
                          <span className="text-primary/80">{entry.wins}W</span>
                          <span>-</span>
                          <span className="text-destructive/80">{entry.losses}L</span>
                          <span>-</span>
                          <span>{entry.pushes}P</span>
                          <span className="mx-1 opacity-30">|</span>
                          <span>{entry.rounds} rounds</span>
                        </div>
                      </div>

                      <span className="text-xs text-muted-foreground/60 font-mono shrink-0">
                        {entry.date}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
