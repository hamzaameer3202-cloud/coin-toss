import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Gift, X, Clock } from "lucide-react";
import { Button } from "@/components/ui/button";
import { DAILY_REWARD_AMOUNT, msUntilNextReward } from "@/lib/persistence";

interface DailyRewardProps {
  visible: boolean;
  available: boolean;
  onClaim: () => void;
  onClose: () => void;
}

function useCountdown(active: boolean) {
  const [label, setLabel] = useState("");

  useEffect(() => {
    if (!active) return;

    const tick = () => {
      const ms = msUntilNextReward();
      const totalSec = Math.floor(ms / 1000);
      const h = Math.floor(totalSec / 3600);
      const m = Math.floor((totalSec % 3600) / 60);
      const s = totalSec % 60;
      setLabel(
        `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`
      );
    };

    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [active]);

  return label;
}

const COIN_POSITIONS = [
  { x: -60, y: -80, rotate: -30, delay: 0 },
  { x: 60, y: -90, rotate: 20, delay: 0.05 },
  { x: -80, y: -30, rotate: -50, delay: 0.1 },
  { x: 80, y: -40, rotate: 40, delay: 0.08 },
  { x: -20, y: -100, rotate: 10, delay: 0.12 },
  { x: 30, y: -110, rotate: -15, delay: 0.15 },
];

export function DailyReward({ visible, available, onClaim, onClose }: DailyRewardProps) {
  const [claimed, setClaimed] = useState(false);
  const [showCoins, setShowCoins] = useState(false);
  const countdown = useCountdown(!available || claimed);

  useEffect(() => {
    if (!visible) {
      setClaimed(false);
      setShowCoins(false);
    }
  }, [visible]);

  const handleClaim = () => {
    setShowCoins(true);
    setClaimed(true);
    onClaim();
    setTimeout(() => setShowCoins(false), 1200);
  };

  return (
    <AnimatePresence>
      {visible && (
        <>
          <motion.div
            key="backdrop"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-black/75 backdrop-blur-sm z-40"
            onClick={onClose}
          />
          <motion.div
            key="panel"
            initial={{ opacity: 0, scale: 0.88, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            exit={{ opacity: 0, scale: 0.92, y: 20 }}
            transition={{ type: "spring", damping: 22, stiffness: 300 }}
            className="fixed inset-x-4 top-1/2 -translate-y-1/2 max-w-sm mx-auto z-50 bg-card border border-border rounded-3xl shadow-2xl overflow-hidden"
            data-testid="daily-reward-panel"
          >
            <button
              onClick={onClose}
              className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors z-10"
              data-testid="button-close-daily-reward"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="relative flex flex-col items-center px-8 pt-10 pb-8 gap-5">

              {/* Coin burst animation */}
              <AnimatePresence>
                {showCoins && COIN_POSITIONS.map((pos, i) => (
                  <motion.div
                    key={i}
                    className="absolute top-1/2 left-1/2 w-6 h-6 rounded-full bg-primary border-2 border-amber-300 shadow-[0_0_8px_rgba(251,191,36,0.8)] pointer-events-none"
                    initial={{ x: 0, y: 0, opacity: 1, scale: 0.5 }}
                    animate={{ x: pos.x, y: pos.y, opacity: 0, scale: 1.2, rotate: pos.rotate }}
                    transition={{ duration: 0.7, delay: pos.delay, ease: "easeOut" }}
                  />
                ))}
              </AnimatePresence>

              {/* Icon */}
              <motion.div
                animate={available && !claimed ? { scale: [1, 1.08, 1], rotate: [0, -6, 6, 0] } : {}}
                transition={{ duration: 2.4, repeat: Infinity, ease: "easeInOut" }}
                className="relative"
              >
                <div className="w-20 h-20 rounded-full bg-primary/15 border border-primary/30 flex items-center justify-center shadow-[0_0_30px_rgba(234,179,8,0.3)]">
                  <Gift className="w-9 h-9 text-primary" />
                </div>
                {available && !claimed && (
                  <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-primary animate-pulse" />
                )}
              </motion.div>

              {/* Title */}
              <div className="text-center">
                <h2 className="text-2xl font-black uppercase tracking-widest text-foreground font-mono">
                  Daily Reward
                </h2>
                <p className="text-muted-foreground text-sm font-mono mt-1">
                  {claimed ? "See you tomorrow!" : available ? "Your coins are waiting" : "Come back tomorrow"}
                </p>
              </div>

              {/* Reward amount */}
              <motion.div
                animate={available && !claimed ? { boxShadow: ["0 0 0px rgba(234,179,8,0)", "0 0 24px rgba(234,179,8,0.5)", "0 0 0px rgba(234,179,8,0)"] } : {}}
                transition={{ duration: 2, repeat: Infinity }}
                className="flex items-baseline gap-2 px-8 py-4 rounded-2xl bg-primary/10 border border-primary/20"
              >
                <span
                  className="text-5xl font-black font-mono text-primary drop-shadow-[0_0_12px_rgba(234,179,8,0.8)]"
                  data-testid="text-reward-amount"
                >
                  +{DAILY_REWARD_AMOUNT}
                </span>
                <span className="text-xl font-mono text-primary/70 font-bold">CR</span>
              </motion.div>

              {/* Action */}
              {available && !claimed ? (
                <Button
                  size="lg"
                  className="w-full h-14 text-lg font-black uppercase tracking-widest bg-primary text-primary-foreground hover:bg-primary/90 shadow-[0_0_20px_rgba(234,179,8,0.4)] hover:shadow-[0_0_32px_rgba(234,179,8,0.7)] transition-all"
                  onClick={handleClaim}
                  data-testid="button-claim-reward"
                >
                  Claim Reward
                </Button>
              ) : (
                <div className="w-full flex flex-col items-center gap-2" data-testid="reward-countdown">
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="w-4 h-4" />
                    <span className="text-xs font-mono uppercase tracking-widest">Next reward in</span>
                  </div>
                  <span className="text-2xl font-mono font-bold text-foreground tracking-widest">
                    {countdown}
                  </span>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-1 font-mono"
                    onClick={onClose}
                    data-testid="button-close-reward-claimed"
                  >
                    Got it
                  </Button>
                </div>
              )}
            </div>
          </motion.div>
        </>
      )}
    </AnimatePresence>
  );
}
