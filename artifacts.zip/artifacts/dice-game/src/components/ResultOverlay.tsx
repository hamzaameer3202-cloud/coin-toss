import { useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

type ResultType = "WIN" | "LOSE" | "PUSH" | null;

interface ResultOverlayProps {
  result: ResultType;
  visible: boolean;
  coinDelta: number;
}

const CONFIG = {
  WIN: {
    label: "Winner!",
    sub: (delta: number) => `+${delta} coins`,
    color: "text-amber-400",
    glow: "drop-shadow-[0_0_40px_rgba(251,191,36,0.95)]",
    bg: "from-amber-500/20 via-amber-400/10 to-transparent",
    border: "border-amber-400/40",
  },
  LOSE: {
    label: "House Wins",
    sub: (delta: number) => `-${delta} coins`,
    color: "text-red-400",
    glow: "drop-shadow-[0_0_40px_rgba(248,113,113,0.95)]",
    bg: "from-red-700/20 via-red-600/10 to-transparent",
    border: "border-red-500/40",
  },
  PUSH: {
    label: "Push",
    sub: () => "Tie — bet returned",
    color: "text-slate-300",
    glow: "drop-shadow-[0_0_20px_rgba(203,213,225,0.5)]",
    bg: "from-slate-600/20 via-slate-500/10 to-transparent",
    border: "border-slate-500/30",
  },
};

export function ResultOverlay({ result, visible, coinDelta }: ResultOverlayProps) {
  if (!result) return null;
  const cfg = CONFIG[result];

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key={result + String(visible)}
          className="fixed inset-0 z-30 flex items-center justify-center pointer-events-none"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.2 }}
          data-testid="result-overlay"
        >
          <div className={`absolute inset-0 bg-gradient-radial ${cfg.bg}`} />

          <motion.div
            className="relative flex flex-col items-center gap-3"
            initial={{ scale: 0.4, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 1.15, opacity: 0, y: -30 }}
            transition={{
              enter: { type: "spring", stiffness: 420, damping: 22 },
              exit: { duration: 0.25, ease: "easeIn" },
            }}
          >
            <span
              className={`font-black uppercase tracking-tighter text-6xl sm:text-8xl leading-none ${cfg.color} ${cfg.glow}`}
              style={{ fontFamily: "var(--app-font-sans)" }}
              data-testid="overlay-label"
            >
              {cfg.label}
            </span>

            <motion.span
              className={`font-mono text-xl sm:text-2xl font-bold px-6 py-2 rounded-full border bg-black/40 backdrop-blur-sm ${cfg.color} ${cfg.border}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.12 }}
              data-testid="overlay-delta"
            >
              {cfg.sub(coinDelta)}
            </motion.span>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
